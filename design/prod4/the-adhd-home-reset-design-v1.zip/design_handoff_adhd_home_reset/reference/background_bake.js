const CW=[{k:'mint',ko:'민트',c:'#7FB59C',d:'#537364',t:'#E4F0EA',paper:'#F3F7F4',w1:'#CFE4EE',w2:'#C4E6D0'},{k:'lemon',ko:'레몬',c:'#E2BE3E',d:'#7D6A28',t:'#F8F0D0',paper:'#F9F8F0',w1:'#D6E7EE',w2:'#F8ECB8'},{k:'lav',ko:'라벤더',c:'#A393D8',d:'#6E6490',t:'#ECE8F8',paper:'#F7F6FA',w1:'#F1D3E5',w2:'#DFD8F4'},{k:'aqua',ko:'아쿠아',c:'#2FB3C6',d:'#237581',t:'#DAF1F4',paper:'#F2F7F8',w1:'#F6DCCB',w2:'#C9ECF2'}];
const SEC={home:'#7FB59C',rooms:'#E2BE3E',weeks:'#A393D8',tools:'#2FB3C6'};
const INK='#2C3631',MUT='#66716B',HAIR='#E9EEEB';
const TABS=[['HOME',SEC.home],['ENERGY',SEC.home],['ROOMS',SEC.rooms],['ROUTINES',SEC.weeks],['WEEKS',SEC.weeks],['TOOLS',SEC.tools]];
function rail(C,active){let h='';TABS.forEach(([l,c],i)=>{const top=12+i*128,on=l===active;
 h+=`<a href="#" style="position:absolute;left:10px;top:${top}px;width:40px;height:128px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px"><span style="width:5px;height:5px;border-radius:50%;background:${on?C.c:c}"></span><span style="writing-mode:vertical-rl;transform:rotate(180deg);font-size:7px;font-weight:${on?800:600};letter-spacing:0.16em;color:${on?INK:'#5F6B65'}">${l}</span></a>`;});return h;}
function head(C,sec,title,sub){return `<div style="position:absolute;left:84px;top:42px;display:flex;align-items:center;gap:6px"><span style="width:2.5px;height:11px;background:${C.c};border-radius:1px"></span><span style="font-size:9px;font-weight:600;color:#5F6B65">${sec}</span></div>
<a href="#p91" style="position:absolute;left:548px;top:30px;width:36px;height:18px;border-radius:9px;background:${C.t};color:${C.d};font-size:7.5px;font-weight:800;letter-spacing:0.1em;display:flex;align-items:center;justify-content:center">SOS</a>
<div style="position:absolute;left:84px;top:58px;font-size:30px;font-weight:800;letter-spacing:-0.02em;line-height:1.1;color:${INK}">${title}</div>
<div style="position:absolute;left:84px;top:98px;font-size:10px;color:${MUT}">${sub}</div>`;}
function mk(){const rects=[];const card=(x,y,w,h,inner,ex='',ban=false)=>{rects.push({x,y,w,h,r:16,ban});return `<div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;height:${h}px;border-radius:16px;background:${ban?'transparent':'#FFFFFF'};box-sizing:border-box;${ex}">${inner}</div>`;};return {rects,card};}
const lab=t=>`<span style="font-size:12px;font-weight:800">${t}</span>`;
const lines=n=>Array.from({length:n},()=>`<div style="height:26px;border-bottom:0.6px solid #E3E9E5"></div>`).join('');
const chip=(C,n,sz=24)=>`<span style="flex:none;width:${sz}px;height:${sz}px;border-radius:50%;background:${C.t};color:${C.d};font-size:${Math.round(sz*0.42)}px;font-weight:800;display:flex;align-items:center;justify-content:center">${n}</span>`;
const PAGES={
 cover(C){const {rects,card}=mk();
  const idx=[['Energy menu','pick by battery and time','4',SEC.home],['Rooms','nine rooms, ten-minute resets','19',SEC.rooms],['Routines & weeks','daily, weekly, the loops','62',SEC.weeks],['Tools','rescue, sprint, declutter','18',SEC.tools]];
  let h=rail(C,'HOME');
  h+=`<div style="position:absolute;left:84px;top:236px;width:500px;display:flex;flex-direction:column;align-items:center;gap:18px;text-align:center"><span style="padding:5px 12px;border-radius:12px;background:${C.t};color:${C.d};font-size:7.5px;font-weight:800;letter-spacing:0.14em">UNDATED · NO-GUILT</span><span style="font-size:52px;font-weight:800;letter-spacing:-0.03em;line-height:1.02;color:${INK}">The ADHD<br>Home Reset</span><span style="font-size:13px;color:${MUT}">Clean by energy, not by schedule.</span></div>`;
  rects.push({x:548,y:30,w:0,h:0,skip:true});
  h+=card(84,520,500,252,idx.map(([t,s,n,c],i)=>`<a href="#" style="display:flex;align-items:center;gap:14px;height:56px;${i?`border-top:0.6px solid ${HAIR};`:''}"><span style="width:7px;height:7px;border-radius:50%;background:${c};flex:none"></span><span style="flex:1;display:flex;flex-direction:column;gap:1px"><span style="font-size:12.5px;font-weight:800">${t}<span style="margin-left:4px)[c]}">→</span></span><span style="font-size:9px;color:${MUT}">${s}</span></span><span style="min-width:24px;height:18px;padding:0 7px;box-sizing:border-box;border-radius:9px;background:${C.t};color:${C.d};font-size:8.5px;font-weight:800;display:flex;align-items:center;justify-content:center">${n}</span></a>`).join(''),'padding:14px 24px;display:flex;flex-direction:column;justify-content:center');
  return {h,rects,tab:0,sos:false,label:'Cover'};},
 start(C){const {rects,card}=mk();
  const S=[['1','Check your battery','Low, medium, or full? Pick a task that fits.'],['2','Pick one room','Tap it on the house map. Ten minutes, then stop.'],['3','All too much?','Tap SOS on any page. Rescue first, tidy later.']];
  let h=rail(C,'HOME')+head(C,'Home','Start here',"Thirty seconds, then you're cleaning.");
  S.forEach(([n,t,s],i)=>h+=card(84,138+i*92,500,78,chip(C,n,28)+`<span style="flex:1;display:flex;flex-direction:column;gap:2px"><span style="font-size:13px;font-weight:800">${t}</span><span style="font-size:9.5px;color:${MUT}">${s}</span></span><span style="font-size:9.5px;font-weight:800">Go<span style="margin-left:4px">→</span></span>`,'padding:0 24px;display:flex;align-items:center;gap:16px'));
  h+=card(84,414,500,56,`<span style="font-size:12px;font-weight:700">Blank boxes are normal. No streaks, no catching up.</span>`,'padding:0 24px;display:flex;align-items:center',true);
  h+=card(84,486,500,290,`<div style="display:flex;gap:10px;align-items:baseline">${lab('The room that bugs me most')}<span style="font-size:8.5px;color:${MUT}">start there next time</span></div>`+lines(9),'padding:18px 24px;display:flex;flex-direction:column');
  return {h,rects,tab:0,sos:true,label:'Start here'};},
 energy(C){const {rects,card}=mk();
  const E=[['Low',[['Take out one bag of trash','Wipe the bathroom sink','Line up the shoes by the door'],['Load five dishes','Start one laundry load','Clear the nightstand'],['Fold one basket sitting down','Empty the car door pockets','Reset the couch and pillows'],['Unload and reload the dishwasher','Sort the mail pile']]],['Medium',[['Wipe the stovetop','Wipe the bathroom mirror'],['Clear the kitchen counter','Pull up the covers','Sweep the entry'],['Clean the toilet','Vacuum one room','Put away one basket'],['Change the sheets','Clean out the fridge']]],['Full',[['Take out the recycling','Swap in fresh hand towels'],['Wipe down the desk','Shake out the door mat'],['Mop the kitchen floor','Scrub the shower walls','Clear the desk to empty'],['Vacuum the car','Deep clean one cabinet','Wash the towels and bath mats']]]];
  const xs=[146,257.5,369,480.5];
  let h=rail(C,'ENERGY')+head(C,'Energy','Energy menu','Pick by battery and time, not by day.');
  h+=['2 MIN','5 MIN','10 MIN','20 MIN'].map((t,i)=>`<div style="position:absolute;left:${xs[i]+12}px;top:138px;font-size:7.5px;font-weight:800;letter-spacing:0.12em;color:${MUT}">${t}</div>`).join('');
  E.forEach(([n,cells],r)=>{const y=156+r*150;h+=`<div style="position:absolute;left:84px;top:${y}px;width:56px;height:138px;display:flex;align-items:center;font-size:12px;font-weight:800">${n}</div>`;
   cells.forEach((it,c)=>h+=card(xs[c],y,103.5,138,it.map(t=>`<div style="display:flex;gap:6px;font-size:8.5px;line-height:1.3"><span style="width:4px;height:4px;border-radius:50%;background:${C.c};margin-top:4px;flex:none"></span><span>${t}</span></div>`).join('')+`<div style="margin-top:auto;height:16px;border-bottom:0.6px solid ${HAIR};font-size:9px;color:${MUT}">+</div>`,'padding:12px 11px 10px;display:flex;flex-direction:column;gap:6px'));});
  h+=card(84,614,500,160,`<div style="display:flex;gap:10px;align-items:baseline">${lab("Today's pick")}<span style="font-size:8.5px;color:${MUT}">one is enough</span></div>`+lines(4),'padding:18px 24px;display:flex;flex-direction:column');
  return {h,rects,tab:1,sos:true,label:'Energy menu'};},
 week(C){const {rects,card}=mk();
  const D=['MON','TUE','WED','THU','FRI','SAT','SUN'],R=['Kitchen','Bathroom','Bedroom','Living room','Desk','Laundry'];
  const grid='display:grid;grid-template-columns:86px repeat(7,minmax(0,1fr));gap:5px';
  let h=rail(C,'WEEKS')+head(C,'Weeks','Reset week 1','One room, ten minutes. Not the whole house.');
  h+=card(84,138,500,272,`<div style="${grid};height:22px;align-items:center">${'<span></span>'+D.map(d=>`<span style="text-align:center;font-size:7.5px;font-weight:800;letter-spacing:0.1em;color:${MUT}">${d}</span>`).join('')}</div>`+R.map(r=>`<div style="${grid};height:36px;align-items:center"><span style="font-size:10.5px;font-weight:700">${r}</span>${D.map(()=>`<span style="height:28px;border-radius:8px;background:${C.t}"></span>`).join('')}</div>`).join(''),'padding:16px 20px;display:flex;flex-direction:column');
  h+=card(84,426,500,348,`<div style="display:flex;gap:10px;align-items:baseline">${lab('The one that bothers me most')}<span style="font-size:8.5px;color:${MUT}">start there</span></div>`+lines(12),'padding:18px 24px;display:flex;flex-direction:column');
  return {h,rects,tab:4,sos:true,label:'Reset week'};},
 rescue(C){const {rects,card}=mk();
  const S=[['1','Trash first','Walk the room with one bag. Only trash.'],['2','Gather the dishes','Everything to the sink. Washing can wait.'],['3','One basket of clothes','Clean or not, into one basket. Sort later.'],['4','Clear a path','Floor things into a box. Just the path.'],['5','One surface','Clear one table or counter. Then stop.']];
  let h=rail(C,'TOOLS')+head(C,'Tools','Rescue mode',"When it's all too much. Rescue, don't organize.");
  S.forEach(([n,t,s],i)=>h+=card(84,138+i*106,500,92,chip(C,n,32)+`<span style="display:flex;flex-direction:column;gap:3px"><span style="font-size:14px;font-weight:800">${t}</span><span style="font-size:10px;color:${MUT}">${s}</span></span>`,'padding:0 26px;display:flex;align-items:center;gap:18px'));
  h+=card(84,676,500,64,`<span style="font-size:13px;font-weight:800">Log it in Wins. Rescue counts.</span><span style="font-size:9.5px;font-weight:800">Wins log<span style="margin-left:4px">→</span></span>`,'padding:0 26px;display:flex;align-items:center;justify-content:space-between',true);
  return {h,rects,tab:5,sos:true,label:'Rescue mode'};},
};
async function bake(C,pg,path){
 const K=2,W=612*K,H=792*K,c=createCanvas(W,H),x=c.getContext('2d');
 const hex=(h,a)=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16},${(n>>8)&255},${n&255},${a})`;};
 x.fillStyle=C.paper;x.fillRect(0,0,W,H);
 const blob=(cx,cy,r,col,a)=>{const g=x.createRadialGradient(cx*K,cy*K,0,cx*K,cy*K,r*K);g.addColorStop(0,hex(col,a));g.addColorStop(1,hex(col,0));x.fillStyle=g;x.fillRect(0,0,W,H);};
 blob(170,0,300,C.w1,0.95);blob(470,40,340,C.w2,0.95);blob(0,560,260,C.w2,0.55);blob(40,860,240,C.w1,0.6);
 const snap=createCanvas(W,H);snap.getContext('2d').drawImage(c,0,0);
 const rr=(X,Y,w,h,r)=>{x.beginPath();x.roundRect(X*K,Y*K,w*K,h*K,r*K);};
 x.save();x.shadowColor='rgba(40,60,55,0.08)';x.shadowBlur=24*K;x.shadowOffsetY=8*K;rr(10,12,40,768,20);x.fillStyle='rgba(255,255,255,0.4)';x.fill();x.restore();
 x.save();rr(10,12,40,768,20);x.clip();x.filter='blur(14px)';x.drawImage(snap,0,0);x.filter='none';x.fillStyle='rgba(255,255,255,0.46)';x.fillRect(0,0,W,H);x.restore();
 const top=12+pg.tab*128, px=14,py=top+10,pw=32,ph=108,pr=16;
 x.save();x.shadowColor=hex(C.d,0.18);x.shadowBlur=6*K;x.shadowOffsetY=2*K;rr(px,py,pw,ph,pr);x.fillStyle=C.t;x.fill();x.restore();
 x.save();rr(px,py,pw,ph,pr);x.clip();
 const cx=(px+pw/2)*K, cy=(py+ph/2)*K, ry=(ph/2-5)*K, sx=(pw/2-3)/(ph/2-5);
 x.translate(cx,cy);x.scale(sx,1);x.translate(-cx,-cy);
 const g=x.createRadialGradient(cx,cy,0,cx,cy,ry);
 g.addColorStop(0,hex(C.d,0.07));g.addColorStop(0.55,hex(C.d,0.04));g.addColorStop(0.84,hex(C.d,0.012));g.addColorStop(0.93,'rgba(255,255,255,0.22)');g.addColorStop(1,'rgba(255,255,255,0)');
 x.fillStyle=g;x.beginPath();x.arc(cx,cy,ry,0,Math.PI*2);x.fill();x.restore();
 if(pg.sos){x.save();x.shadowColor=hex(C.d,0.18);x.shadowBlur=6*K;x.shadowOffsetY=2*K;rr(548,30,36,18,9);x.fillStyle=C.t;x.fill();x.restore();}
 pg.rects.filter(q=>!q.skip).forEach(q=>{x.fillStyle=q.ban?C.w2:'#FFFFFF';
  const pth=()=>{x.beginPath();x.roundRect(q.x*K,q.y*K,q.w*K,q.h*K,q.r*K);};
  x.save();x.shadowColor='rgba(40,60,55,0.07)';x.shadowBlur=34*K;x.shadowOffsetY=14*K;pth();x.fill();x.restore();
  x.save();x.shadowColor='rgba(40,60,55,0.07)';x.shadowBlur=4*K;x.shadowOffsetY=1*K;pth();x.fill();x.restore();
  if(q.ban){x.save();pth();x.clip();const lg=x.createLinearGradient(q.x*K,0,(q.x+q.w)*K,0);lg.addColorStop(0,C.w1);lg.addColorStop(1,C.w2);x.fillStyle=lg;x.fillRect(q.x*K,q.y*K,q.w*K,q.h*K);
    const rg=x.createRadialGradient((q.x+q.w*0.8)*K,q.y*K,0,(q.x+q.w*0.8)*K,q.y*K,160*K);rg.addColorStop(0,'rgba(255,255,255,0.45)');rg.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=rg;x.fillRect(q.x*K,q.y*K,q.w*K,q.h*K);x.restore();}
 });
 if(path.endsWith('.jpg')){const b=c.convertToBlob?await c.convertToBlob({type:'image/jpeg',quality:0.85}):await (await fetch(c.toDataURL('image/jpeg',0.85))).blob();await saveFile(path,b);} else await saveFile(path,c);
}
function pageHTML(C,key,pg,id){const img=`assets/15-${key}-${C.k}.png`;return {img,html:`<div data-screen-label="${id} · ${pg.label} · ${C.ko}" style="position:relative;width:612px;height:792px;overflow:hidden;flex:none;font-family:'Nunito',sans-serif;color:${INK};background:${C.paper}"><img src="${img}" alt="" style="position:absolute;left:0;top:0;width:612px;height:792px">${pg.h}</div>`};}
return {CW,PAGES,bake,pageHTML,rail,head,mk,lab,lines,chip,INK,MUT,HAIR};
