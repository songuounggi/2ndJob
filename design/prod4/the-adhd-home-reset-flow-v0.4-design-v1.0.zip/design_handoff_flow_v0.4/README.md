# 2쪽 How it flows — 회신 (인수인계서 v0.4 → Claude Code)

**보내는 쪽:** claude.ai/design (2026-10-02) → **받는 쪽:** Claude Code (`Prod 4. The ADHD Home Reset`)
**최종안:** 시안 `ADHD Home Reset - Concepts.dc.html` TURN 34 · **34e** (사용자 결정). 다른 37쪽은 TURN 25 그대로.

## 1. 묶음 안의 파일
| 파일 | 무엇 |
|---|---|
| `page2_34e.html` | 2쪽 한 장 (612×792pt, v1.0과 같은 형식 — 절대 위치 + 배경 JPG + 실제 텍스트 + SVG 선). 브라우저로 바로 열림 |
| `assets/page2-bg.jpg` | 2쪽 배경 (1224×1584px, JPG 품질 85, 약 30KB). 번짐 · 탭 레일 유리 · SOS · 모든 그림자 미리 구움 |
| `assets/card-shadow.png` | Open the planner 알약 그림자 (기존 파일 그대로) |
| `page2_34e.png` | 참고 그림 (1224×1584px, 브라우저에서 찍은 2쪽 완성 모습). 빌드 후 눈 비교용 — 좌표는 HTML 기준 |

**넣는 곳:** zip 그대로 `C:\Users\ThinkBook\AiProject\2ndJob\design\prod4\` — 파일 이름 `design_handoff_flow_v0.4.zip`. v1.0 zip은 그대로 두고 2쪽만 갈아 끼운다.
**배경:** 그림자를 이미 구운 JPG를 보냄 → 새로 굽지 않아도 됨. 다시 굽는다면 §6 값 사용(링크 카드는 `card-shadow.png` 비율 배치, ◇는 점 그림자 값).

## 2. 구조 (v0.4 선 그림과 같음)
Open the planner → ◇ How's today? → Doable(왼쪽 · 민트) / All too much(오른쪽 · 아쿠아)
- Doable → ◇ How to pick? → Energy menu(왼쪽 · 민트) / House map(오른쪽 · 레몬) → 합쳐짐 → Do that one thing, then stop(링크 없음)
- All too much → Rescue mode
- 두 갈래 합쳐짐 → Wins log
- 따로: Every week

## 3. 링크 영역 6개 = 쪽 6개 (사각형 · pt · 왼쪽 x, 위 y, 폭 × 높이)
| 링크 | 쪽 | 영역 |
|---|---|---|
| Open the planner → | 3쪽 | 284, 166, 140 × 28 (알약, 모서리 14) |
| Energy menu → | 6쪽 | 104, 443.94, 110 × 58 |
| House map → | 4쪽 | 234, 443.94, 110 × 58 |
| Rescue mode → | 94쪽 | 404, 331.94, 160 × 70 |
| Wins log → | 103쪽 | 274, 611.94, 160 × 58 |
| Every week → | 40쪽 | 254, 700, 200 × 52 |

(SOS 칩 → 91쪽, 탭 레일 6개는 기존 그대로.) 같은 쪽으로 가는 상자 없음.
**링크 아님(→ 없음):** How's today? · How to pick? · Doable · All too much · Do that one thing, then stop.

## 4. 글자 (Nunito, 색 글자는 섹션 진한색)
| 무엇 | 크기 · 굵기 | 색 |
|---|---|---|
| Open the planner | 11 · 800 | 검정 #2C3631, → #537364 |
| 질문 How's today? / How to pick? | 10.5 · 800 | #2C3631 |
| 갈래 이름 Doable / All too much | 10 · 800 | #537364 / #237581 |
| Energy menu · House map 제목 / 한 줄(두 줄로 나눔) | 11 · 800 / 8 · 700 | 민트 #537364 · 레몬 #7D6A28 |
| Rescue mode 제목 / 한 줄 / 작은 줄 | 11.5 · 800 / 8.5 · 700 / 7.5 · 600 | #237581 |
| Do that one thing, then stop | 11 · 800 | #2C3631 |
| Wins log 제목 / It counts | 15 · 800 / 9.5 · 800 | #237581 |
| Every week 제목 / Reset week… | 15 · 800 / 9.5 · 800 (Wins log와 같은 값) | #6E6490 |

- 갈래 이름 위치: Doable은 민트 선 **왼쪽**(글자 오른쪽 끝 ~ 선 8pt), All too much는 아쿠아 선 **오른쪽**(선 ~ 글자 8pt).
- 글자 + → 간격 4pt (margin), → 색 = 섹션 진한색 (README §7-2 그대로).

## 5. 선 · 도형 (SVG 한 장, 벡터)
- **선 굵기 2.5pt**, 둥근 끝 · 둥근 꺾임(반지름 8pt). 화살촉 6pt 삼각형(선 색).
- 선 색: Doable · Energy menu 갈래 = 민트 #7FB59C / House map 갈래 = 레몬 #E2BE3E / All too much · 합친 뒤 Wins log까지 = 아쿠아 #2FB3C6.
- **선 겹침 순서:** 위 갈림(How to pick? 아래)은 레몬 선이 민트 선 위, 아래 합침(Do that one thing 위)은 민트 선이 레몬 선 위.
- **화살표 길이:** Open the planner 아래 ~ How's today? 꼭짓점 = Wins log 위 가로선 ~ 카드 위 끝 (약 21.2pt, 가로선 두께 포함, 브라우저 실측 차이 0.03pt).
- **질문 ◇:** 둥근 마름모(45도 돌린 정사각형, 반대각선 46pt, 모서리 8pt). 안쪽은 갈라지는 두 길 색으로 반반(옅은 톤):
  How's today? = 왼쪽 #E4F0EA / 오른쪽 #DAF1F4, How to pick? = 왼쪽 #E4F0EA / 오른쪽 #F8F0D0. 반반은 clipPath(사각형)로 자름 — 벡터.
  중심: How's today? (354, 257.94), How to pick? (224, 361.94).
- 합친 자리(Do that one thing) 위 점 없음, 글자만.
- **카드:** 모서리 12pt, 채움 = 섹션 옅은 색 — Energy menu #E4F0EA · House map #F8F0D0 · Rescue mode · Wins log #DAF1F4 · Every week #ECE8F8. 외곽선 없음.
- Every week 카드 왼쪽에 라벤더 고리(원 r7.5, 선 2.5 #A393D8 + 위쪽 흰 점 r3.6 · 라벤더 점 r2.2) — 인라인 SVG.
- 순서도 전체 좌우 가운데: 왼쪽 끝 104pt · 오른쪽 끝 564pt (본문 84~584 안 좌우 20pt).

## 6. 그림자 (배경 JPG에 구움 — `bake()`로 다시 만들 때)
배경 원본 = TURN 25 2쪽 배경(`25-flow.jpg`)에서 옛 점 8개 자국을 지운 것. 2배(1224×1584)로 굽는다.
1. **링크 카드 5개 (Energy menu · House map · Rescue mode · Wins log · Every week) = Open the planner와 같은 그림자.**
   `card-shadow.png`를 카드마다 같은 비율로 놓는다: 왼쪽 = x − 8.4, 위 = y + h − 12.6, 폭 = w + 16.8, 높이 = 34.8 (pt).
2. **질문 ◇ 2개 = 점 그림자 값:** rgba(40,60,55,0.10) · blur 8 · 아래로 2. 밑판은 ◇보다 1.5pt 안쪽(반대각선 44.5, 모서리 7.5) — 가장자리 흰 선 방지.
3. Open the planner 알약: 기존 `card-shadow.png` 그대로 (275.6, 181.4, 156.8 × 34.8).

## 7. GoodNotes 안전 점검 (README §5)
CSS 그라데이션 · 반투명 · box-shadow · blur · 반복 배경 **없음** (page2_34e.html 검색 확인). 그림자는 모두 배경 JPG. 링크 영역은 사각형. 글자는 실제 텍스트.

## 8. 이번에 새로 정한 값 (사용자 34e 승인 — 규칙 칸에 옮길지 확인)
- 순서도 선 굵기 2.5pt · 화살촉 6pt · 꺾임 반지름 8pt (v1.0 노선도는 4pt)
- 순서도 카드 모서리 12pt (쪽 카드는 16pt)
- 링크 카드 그림자 = Open the planner 그림자 (`card-shadow.png` 비율 배치)
- 질문 ◇: 둥근 모서리 + 갈라지는 두 길 색 반반 (CLAUDE.md [Prod 4] 규칙에 이미 적음)

## 8-1. 코드 메모
- 탭 레일 6개 `href="#"` 는 v1.0 시안과 같은 자리표시 — 빌드에서 각 섹션 첫 쪽으로 연결.
- `<head>` 의 `body` 스타일(회색 바탕 · 가운데 · 여백 24)은 미리보기용. 2쪽 덩어리는 `<div data-page="2">` 하나.
- SVG 안 marker 3개 · clipPath 2개는 모두 쓰임. 쓰지 않는 코드 · 주석 없음.

## 8-2. Claude Code 확인 항목 대조 (design 쪽 사전 점검)
- 질문 ◇ 2개 (How's today? · How to pick?) ✔
- 누르는 곳 6개 = 쪽 6개: #p3 · #p6 · #p4 · #p94 · #p103 · #p40 ✔ (+ SOS #p91, 탭 레일) · 같은 쪽 상자 없음 ✔
- 문구 = 인수인계서 v0.4 §3 전부 일치 ✔ (Energy menu · House map 한 줄은 두 줄로 나눠 놓았을 뿐 글자 같음)
- iPad 위험 효과(그라데이션 · 반투명 · box-shadow · blur · 반복 배경) 없음 ✔

## 9. 받은 뒤 할 일 (인수인계서 v0.4 §6)
`scripts/p4/build_v2_p4.py` 2쪽에 옮기고 빌드 → 링크 6개 = 쪽 6개 · 같은 쪽 상자 없음 · 글자 넘침/겹침 · 흑백판 · GoodNotes 위험 효과 · 속도 검사 → 사용자 확인.
문구 변경 없음 (v0.4 §3 그대로).
